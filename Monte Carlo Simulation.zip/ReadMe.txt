Monte Carlo Simulation for IMPULSED fitting with cellular substrates with increasing cell density
(Run the Camino )

"datasynth_cell_p0_IncDensity_d10um.sh" is the main simulation file that contains command to generate signals for cellular substrates of impermeable spheres in square packing, with the cell diameter fixed at 10 µm and varying cell separations from 10-15 µm in 0.5 µm steps

"OGSE_wave_17Hz_b400.txt" etc. are the gradient waveform files defined for different oscillating frequencies and different b-values

"r5.ply" is the polygon file that defines the cellular substrate.
