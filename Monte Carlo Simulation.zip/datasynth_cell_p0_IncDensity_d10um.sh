cd /home/zju/Documents/Simulations/Prostate
datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1e-05 1e-05 1e-05 -schemefile OGSE_wave_33Hz_b300.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b300_Sep10um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1e-05 1e-05 1e-05 -schemefile OGSE_wave_33Hz_b600.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b600_Sep10um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1e-05 1e-05 1e-05 -schemefile OGSE_wave_33Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b400_Sep10um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1e-05 1e-05 1e-05 -schemefile OGSE_wave_33Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b800_Sep10um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1e-05 1e-05 1e-05 -schemefile OGSE_wave_33Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b1200_Sep10um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1e-05 1e-05 1e-05 -schemefile OGSE_wave_17Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b400_Sep10um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1e-05 1e-05 1e-05 -schemefile OGSE_wave_17Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b800_Sep10um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1e-05 1e-05 1e-05 -schemefile OGSE_wave_17Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b1200_Sep10um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1e-05 1e-05 1e-05 -schemefile PGSE_wave_30ms_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b400_Sep10um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1e-05 1e-05 1e-05 -schemefile PGSE_wave_30ms_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b800_Sep10um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1e-05 1e-05 1e-05 -schemefile PGSE_wave_30ms_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b1200_Sep10um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.05e-05 1.05e-05 1.05e-05 -schemefile OGSE_wave_33Hz_b300.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b300_Sep10.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.05e-05 1.05e-05 1.05e-05 -schemefile OGSE_wave_33Hz_b600.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b600_Sep10.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.05e-05 1.05e-05 1.05e-05 -schemefile OGSE_wave_33Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b400_Sep10.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.05e-05 1.05e-05 1.05e-05 -schemefile OGSE_wave_33Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b800_Sep10.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.05e-05 1.05e-05 1.05e-05 -schemefile OGSE_wave_33Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b1200_Sep10.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.05e-05 1.05e-05 1.05e-05 -schemefile OGSE_wave_17Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b400_Sep10.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.05e-05 1.05e-05 1.05e-05 -schemefile OGSE_wave_17Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b800_Sep10.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.05e-05 1.05e-05 1.05e-05 -schemefile OGSE_wave_17Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b1200_Sep10.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.05e-05 1.05e-05 1.05e-05 -schemefile PGSE_wave_30ms_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b400_Sep10.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.05e-05 1.05e-05 1.05e-05 -schemefile PGSE_wave_30ms_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b800_Sep10.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.05e-05 1.05e-05 1.05e-05 -schemefile PGSE_wave_30ms_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b1200_Sep10.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.1e-05 1.1e-05 1.1e-05 -schemefile OGSE_wave_33Hz_b300.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b300_Sep11um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.1e-05 1.1e-05 1.1e-05 -schemefile OGSE_wave_33Hz_b600.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b600_Sep11um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.1e-05 1.1e-05 1.1e-05 -schemefile OGSE_wave_33Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b400_Sep11um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.1e-05 1.1e-05 1.1e-05 -schemefile OGSE_wave_33Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b800_Sep11um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.1e-05 1.1e-05 1.1e-05 -schemefile OGSE_wave_33Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b1200_Sep11um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.1e-05 1.1e-05 1.1e-05 -schemefile OGSE_wave_17Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b400_Sep11um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.1e-05 1.1e-05 1.1e-05 -schemefile OGSE_wave_17Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b800_Sep11um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.1e-05 1.1e-05 1.1e-05 -schemefile OGSE_wave_17Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b1200_Sep11um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.1e-05 1.1e-05 1.1e-05 -schemefile PGSE_wave_30ms_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b400_Sep11um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.1e-05 1.1e-05 1.1e-05 -schemefile PGSE_wave_30ms_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b800_Sep11um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.1e-05 1.1e-05 1.1e-05 -schemefile PGSE_wave_30ms_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b1200_Sep11um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.15e-05 1.15e-05 1.15e-05 -schemefile OGSE_wave_33Hz_b300.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b300_Sep11.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.15e-05 1.15e-05 1.15e-05 -schemefile OGSE_wave_33Hz_b600.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b600_Sep11.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.15e-05 1.15e-05 1.15e-05 -schemefile OGSE_wave_33Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b400_Sep11.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.15e-05 1.15e-05 1.15e-05 -schemefile OGSE_wave_33Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b800_Sep11.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.15e-05 1.15e-05 1.15e-05 -schemefile OGSE_wave_33Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b1200_Sep11.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.15e-05 1.15e-05 1.15e-05 -schemefile OGSE_wave_17Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b400_Sep11.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.15e-05 1.15e-05 1.15e-05 -schemefile OGSE_wave_17Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b800_Sep11.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.15e-05 1.15e-05 1.15e-05 -schemefile OGSE_wave_17Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b1200_Sep11.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.15e-05 1.15e-05 1.15e-05 -schemefile PGSE_wave_30ms_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b400_Sep11.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.15e-05 1.15e-05 1.15e-05 -schemefile PGSE_wave_30ms_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b800_Sep11.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.15e-05 1.15e-05 1.15e-05 -schemefile PGSE_wave_30ms_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b1200_Sep11.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.2e-05 1.2e-05 1.2e-05 -schemefile OGSE_wave_33Hz_b300.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b300_Sep12um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.2e-05 1.2e-05 1.2e-05 -schemefile OGSE_wave_33Hz_b600.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b600_Sep12um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.2e-05 1.2e-05 1.2e-05 -schemefile OGSE_wave_33Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b400_Sep12um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.2e-05 1.2e-05 1.2e-05 -schemefile OGSE_wave_33Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b800_Sep12um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.2e-05 1.2e-05 1.2e-05 -schemefile OGSE_wave_33Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b1200_Sep12um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.2e-05 1.2e-05 1.2e-05 -schemefile OGSE_wave_17Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b400_Sep12um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.2e-05 1.2e-05 1.2e-05 -schemefile OGSE_wave_17Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b800_Sep12um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.2e-05 1.2e-05 1.2e-05 -schemefile OGSE_wave_17Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b1200_Sep12um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.2e-05 1.2e-05 1.2e-05 -schemefile PGSE_wave_30ms_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b400_Sep12um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.2e-05 1.2e-05 1.2e-05 -schemefile PGSE_wave_30ms_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b800_Sep12um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.2e-05 1.2e-05 1.2e-05 -schemefile PGSE_wave_30ms_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b1200_Sep12um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.25e-05 1.25e-05 1.25e-05 -schemefile OGSE_wave_33Hz_b300.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b300_Sep12.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.25e-05 1.25e-05 1.25e-05 -schemefile OGSE_wave_33Hz_b600.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b600_Sep12.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.25e-05 1.25e-05 1.25e-05 -schemefile OGSE_wave_33Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b400_Sep12.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.25e-05 1.25e-05 1.25e-05 -schemefile OGSE_wave_33Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b800_Sep12.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.25e-05 1.25e-05 1.25e-05 -schemefile OGSE_wave_33Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b1200_Sep12.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.25e-05 1.25e-05 1.25e-05 -schemefile OGSE_wave_17Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b400_Sep12.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.25e-05 1.25e-05 1.25e-05 -schemefile OGSE_wave_17Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b800_Sep12.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.25e-05 1.25e-05 1.25e-05 -schemefile OGSE_wave_17Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b1200_Sep12.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.25e-05 1.25e-05 1.25e-05 -schemefile PGSE_wave_30ms_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b400_Sep12.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.25e-05 1.25e-05 1.25e-05 -schemefile PGSE_wave_30ms_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b800_Sep12.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.25e-05 1.25e-05 1.25e-05 -schemefile PGSE_wave_30ms_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b1200_Sep12.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.3e-05 1.3e-05 1.3e-05 -schemefile OGSE_wave_33Hz_b300.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b300_Sep13um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.3e-05 1.3e-05 1.3e-05 -schemefile OGSE_wave_33Hz_b600.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b600_Sep13um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.3e-05 1.3e-05 1.3e-05 -schemefile OGSE_wave_33Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b400_Sep13um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.3e-05 1.3e-05 1.3e-05 -schemefile OGSE_wave_33Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b800_Sep13um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.3e-05 1.3e-05 1.3e-05 -schemefile OGSE_wave_33Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b1200_Sep13um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.3e-05 1.3e-05 1.3e-05 -schemefile OGSE_wave_17Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b400_Sep13um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.3e-05 1.3e-05 1.3e-05 -schemefile OGSE_wave_17Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b800_Sep13um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.3e-05 1.3e-05 1.3e-05 -schemefile OGSE_wave_17Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b1200_Sep13um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.3e-05 1.3e-05 1.3e-05 -schemefile PGSE_wave_30ms_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b400_Sep13um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.3e-05 1.3e-05 1.3e-05 -schemefile PGSE_wave_30ms_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b800_Sep13um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.3e-05 1.3e-05 1.3e-05 -schemefile PGSE_wave_30ms_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b1200_Sep13um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.35e-05 1.35e-05 1.35e-05 -schemefile OGSE_wave_33Hz_b300.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b300_Sep13.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.35e-05 1.35e-05 1.35e-05 -schemefile OGSE_wave_33Hz_b600.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b600_Sep13.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.35e-05 1.35e-05 1.35e-05 -schemefile OGSE_wave_33Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b400_Sep13.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.35e-05 1.35e-05 1.35e-05 -schemefile OGSE_wave_33Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b800_Sep13.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.35e-05 1.35e-05 1.35e-05 -schemefile OGSE_wave_33Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b1200_Sep13.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.35e-05 1.35e-05 1.35e-05 -schemefile OGSE_wave_17Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b400_Sep13.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.35e-05 1.35e-05 1.35e-05 -schemefile OGSE_wave_17Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b800_Sep13.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.35e-05 1.35e-05 1.35e-05 -schemefile OGSE_wave_17Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b1200_Sep13.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.35e-05 1.35e-05 1.35e-05 -schemefile PGSE_wave_30ms_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b400_Sep13.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.35e-05 1.35e-05 1.35e-05 -schemefile PGSE_wave_30ms_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b800_Sep13.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.35e-05 1.35e-05 1.35e-05 -schemefile PGSE_wave_30ms_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b1200_Sep13.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.4e-05 1.4e-05 1.4e-05 -schemefile OGSE_wave_33Hz_b300.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b300_Sep14um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.4e-05 1.4e-05 1.4e-05 -schemefile OGSE_wave_33Hz_b600.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b600_Sep14um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.4e-05 1.4e-05 1.4e-05 -schemefile OGSE_wave_33Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b400_Sep14um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.4e-05 1.4e-05 1.4e-05 -schemefile OGSE_wave_33Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b800_Sep14um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.4e-05 1.4e-05 1.4e-05 -schemefile OGSE_wave_33Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b1200_Sep14um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.4e-05 1.4e-05 1.4e-05 -schemefile OGSE_wave_17Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b400_Sep14um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.4e-05 1.4e-05 1.4e-05 -schemefile OGSE_wave_17Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b800_Sep14um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.4e-05 1.4e-05 1.4e-05 -schemefile OGSE_wave_17Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b1200_Sep14um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.4e-05 1.4e-05 1.4e-05 -schemefile PGSE_wave_30ms_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b400_Sep14um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.4e-05 1.4e-05 1.4e-05 -schemefile PGSE_wave_30ms_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b800_Sep14um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.4e-05 1.4e-05 1.4e-05 -schemefile PGSE_wave_30ms_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b1200_Sep14um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.45e-05 1.45e-05 1.45e-05 -schemefile OGSE_wave_33Hz_b300.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b300_Sep14.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.45e-05 1.45e-05 1.45e-05 -schemefile OGSE_wave_33Hz_b600.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b600_Sep14.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.45e-05 1.45e-05 1.45e-05 -schemefile OGSE_wave_33Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b400_Sep14.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.45e-05 1.45e-05 1.45e-05 -schemefile OGSE_wave_33Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b800_Sep14.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.45e-05 1.45e-05 1.45e-05 -schemefile OGSE_wave_33Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b1200_Sep14.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.45e-05 1.45e-05 1.45e-05 -schemefile OGSE_wave_17Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b400_Sep14.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.45e-05 1.45e-05 1.45e-05 -schemefile OGSE_wave_17Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b800_Sep14.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.45e-05 1.45e-05 1.45e-05 -schemefile OGSE_wave_17Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b1200_Sep14.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.45e-05 1.45e-05 1.45e-05 -schemefile PGSE_wave_30ms_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b400_Sep14.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.45e-05 1.45e-05 1.45e-05 -schemefile PGSE_wave_30ms_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b800_Sep14.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.45e-05 1.45e-05 1.45e-05 -schemefile PGSE_wave_30ms_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b1200_Sep14.5um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.5e-05 1.5e-05 1.5e-05 -schemefile OGSE_wave_33Hz_b300.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b300_Sep15um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.5e-05 1.5e-05 1.5e-05 -schemefile OGSE_wave_33Hz_b600.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b600_Sep15um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.5e-05 1.5e-05 1.5e-05 -schemefile OGSE_wave_33Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b400_Sep15um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.5e-05 1.5e-05 1.5e-05 -schemefile OGSE_wave_33Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b800_Sep15um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.5e-05 1.5e-05 1.5e-05 -schemefile OGSE_wave_33Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE33Hz_b1200_Sep15um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.5e-05 1.5e-05 1.5e-05 -schemefile OGSE_wave_17Hz_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b400_Sep15um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.5e-05 1.5e-05 1.5e-05 -schemefile OGSE_wave_17Hz_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b800_Sep15um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.5e-05 1.5e-05 1.5e-05 -schemefile OGSE_wave_17Hz_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/OGSE17Hz_b1200_Sep15um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.5e-05 1.5e-05 1.5e-05 -schemefile PGSE_wave_30ms_b400.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b400_Sep15um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.5e-05 1.5e-05 1.5e-05 -schemefile PGSE_wave_30ms_b800.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b800_Sep15um.Bfloat

datasynth -walkers 10000 -tmax 1000 -p 0.0 -voxels 1 -snr 100 -initial uniform -voxelsizefrac 1 -diffusivity 2.0E-9 -meshsep 1.5e-05 1.5e-05 1.5e-05 -schemefile PGSE_wave_30ms_b1200.txt -substrate ply -plyfile cell_model/r5.ply -substratesize 1E-4 -outputfile Bfloat1/PGSE30ms_b1200_Sep15um.Bfloat

