clear all
clc
close all

pwd
cd(pwd)

%% read datda
nx = 80; ny = 80; nz = 10; % image size
scans = {'33Hz', '17Hz', '30ms'};
nbval = [2 3 3]; % number of b-values for each oscillating frequency
ndir = 1; % one diffusion directions per b-value

smallDelta = [60 60 60 60 60 20 20 20]'*1e-3;   % Define diffusion duration for the OGSE33Hz, OGSE17Hz, and PGSE30ms scans
bigDelta = [64 64 64 64 64 30 30 30]'*1e-3;     % Define diffusion separation for the OGSE33Hz, OGSE17Hz, and PGSE30ms scans
freq = [33 33 17 17 17 0 0 0]';                 % Define oscillating frequency for the OGSE33Hz, OGSE17Hz, and PGSE30ms scans
Grad = [46 59 27.5 38.9 47.6 27 38 46.5]'*1e-3;   % Define gradient strength for the OGSE33Hz, OGSE17Hz, and PGSE30ms scans, Convert mT/m to T/m
bval = [300 600 400 800 1200 400 800 1200]'*1e6;   % Define b-value for the OGSE33Hz, OGSE17Hz, and PGSE30ms scans, Convert from s/mm2 to s/m2

Nrand = 100;    % number of randomized initalization
f_init = linspace(0.4, 0.9, 100);   % Initalization for fin
d_init = linspace(5, 20, 100);      % Initalization for diameter, unit um
Dex_init = linspace(1.5, 2.5, 100); % Initalization for Dex, unit um2/ms

lb = [0.01 1  0.1]; % upper bound for fin, d, and Dex
ub = [1   100 3.5]; % lower bound for fin, d, and Dex

data = zeros([nx, ny, nz, length(freq)]);
% *** Better to perform registration betweent the different DWIs before reading the data ***
nii = load_untouch_nii('OGep2d_33Hz_b500_TRACEW.nii');
data(:,:,:,1:3) = nii.img;
nii = load_untouch_nii('OGep2d_17Hz_b0.5k1k1.5k_TRACEW.nii');
data(:,:,:,4:7) = nii.img;
nii = load_untouch_nii('OGep2d_30ms_b0.5k1k1.5k_TRACEW.nii');
data(:,:,:,8:11) = nii.img;

% mask = squeeze(data(:,:,:,6)>20);   % tumor mask based on b1k of the 17Hz data, or use manually defined ROI
nii = load_untouch_nii('ROI.nii');  % manually defined ROI
mask = nii.img;
nzIdx = find(mask>0);
S0 = zeros(length(nzIdx), 8);
S = zeros(length(nzIdx), 8);
data = reshape(data, [nx*ny*nz, 11]);
S0(:,1:2) = repmat(data(nzIdx,1), [1 2]);
S0(:,3:5) = repmat(data(nzIdx,4), [1 3]);
S0(:,6:8) = repmat(data(nzIdx,8), [1 3]);
S(:,1:2) = data(nzIdx,2:3);
S(:,3:5) = data(nzIdx,5:7);
S(:,6:8) = data(nzIdx,9:11);

%% lsqcurvefit fitting for S = IMPULSED_fixDin_trapCos(x, seqParams)
% x = [fin, diameter,Din];
% seqParams = [smallDelta, bigDelta, freq, Grad, bval];
% Assuming Din = 1e-3 mm2/s, Beta = 0, and fit for fin, diameter, and Dex
% Randomly generated initial parameter values were used, and the smallest fitting residual were chosen as the final results.

f_intra = zeros(length(nzIdx), 1);
diameter = f_intra;
Dex = f_intra;
xdata = [smallDelta, bigDelta, freq, Grad, bval];
parfor i = 1:length(nzIdx)
    random_init = [randsample(f_init,Nrand); randsample(d_init,Nrand); randsample(Dex_init,Nrand)];
    residRMS = zeros(Nrand, 1);
    fitParams = zeros(3, Nrand);
    ydata = S(i,:)./(S0(i,:)+1);
    ydata = ydata';
    for k = 1:Nrand
        x0 = random_init(:,k);
        [x,~,residual] = lsqcurvefit(@IMPULSED_fixDin_trapCos,x0,xdata,ydata,lb,ub);
        residRMS(k) = sqrt(mean(residual.^2));
        fitParams(:,k) = x;
    end
    [~, idx] = min(residRMS);
    f_intra(i) = fitParams(1, idx);
    diameter(i) = fitParams(2, idx);
    Dex(i) = fitParams(3, idx);
end

% save the data
f_intra_map = zeros([nx ny nz]);
f_intra_map(nzIdx) = f_intra;
nii1 = make_nii(f_intra_map, nii.hdr.dime.pixdim(2:4), [], 16);
save_nii(nii1, [subjectpath2, '\fin_IMPULSED.nii']);

diameter_map = zeros([nx ny nz]);
diameter_map(nzIdx) = diameter;
nii1.img = diameter_map;
save_nii(nii1, [subjectpath2, '\diameter_IMPULSED.nii']);

Dex_map = zeros(nx*ny*nz, 1);
Dex_map(nzIdx) = Dex;
Dex_map = reshape(Dex_map, [nx, ny, nz]);
nii1.img = Dex_map;
save_nii(nii1, [subjectpath2, '\Dex_IMPULSED.nii']);

density = f_intra_map./diameter_map;
nii1.img = density*100;
save_nii(nii1, [subjectpath2, '\cellularity_IMPULSED.nii']);

