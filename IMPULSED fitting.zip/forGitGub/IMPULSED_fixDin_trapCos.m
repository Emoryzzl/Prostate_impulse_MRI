function S = IMPULSED_fixDin_trapCos(x, seqParams)
% x = [fin, diameter,Din];
%       x(1)  x(2)   x(3)
% seqParams = [smallDelta, bigDelta, freq, Grad, bval];
%               p(1)        p(2)     p(3)   p(4)  p(5)
% grad in unit of T/m
% diameter in unit of meter
% Din, Dex in unit of m^2/s
% smallDelta and bigDelta in unit of second
K = 10;
%Din = 1e-9;
x = [x(1), x(2)*1e-6, x(3)*1e-9];
Dex=1.78e-9;
S = zeros(size(seqParams, 1), 1);
for k = 1:size(seqParams, 1)
    if seqParams(k,3)==17
    %     bval = bvalue_trapOGSE(freq, smallDelta, 0.15, Grad);
        Sin = sig_OGSE1(x(2), x(3), seqParams(k,1), seqParams(k,2), seqParams(k,3), seqParams(k,4), K);
    elseif seqParams(k,3)==33
        
        Sin = sig_OGSE2(x(2), x(3), seqParams(k,1), seqParams(k,2), seqParams(k,3), seqParams(k,4), K);
    elseif seqParams(k,3)==0
    %     bval = bvalue_PGSE(smallDelta, bigDelta, 0.15, Grad);
        Sin = sig_PGSE(x(2), x(3), seqParams(k,1), seqParams(k,2), seqParams(k,4), K);     
    end
    
    Sex = exp(-seqParams(k,5)*Dex);
    S(k) = x(1)*Sin + (1-x(1))*Sex;
end


% Sin for PGSE
function S = sig_PGSE(diameter, Din, smallDelta, bigDelta, Grad, K)
% By Li Hua
% gdiff = gdiff.*1e2; delta = delta.*1e-3; Delta = Delta.*1e-3; D = D.*1e-9; radius = radius.*1e-6;
% gamma_1 = 267.5e6;
gamma = 267.513e6; % rad/(s*T)

tmp = 0;
for k = 1:K
    [Bk, lambda_k] = calcBk(diameter, k);
    tt = lambda_k*Din;
    tr=0.9*1e-3;
    tp=smallDelta-2*tr;
%     tmp = tmp+2*Bk*gamma^2*Grad^2/tt^2*(tt*smallDelta-1 + exp(-tt*smallDelta))...
%         + exp(-tt*bigDelta)*(1-cosh(tt*smallDelta));
% Break cosh(x) into (exp(x)+exp(-x))/2, according to Li Hua
    tmp = tmp+ Bk/(tt^4*tr^2)*(2*exp(-tt*tp)-4*exp(-bigDelta*tt)-4*tt*tr+2*exp(-tt*(bigDelta-tr))+2*exp(-tt*(bigDelta+tr))...
        -exp(-tt*(bigDelta-tp))-exp(-tt*(bigDelta+tp))-4*exp(-tt*(tr+tp))+2*exp(-tt*(2*tr+tp))+4/3*tt^3*tr^3+2*tt^3*tr^2*tp...
        +2*exp(-tt*(bigDelta-tr-tp))+2*exp(-tt*(bigDelta+tr+tp))-exp(-tt*(bigDelta-2*tr-tp))-exp(-tt*(bigDelta+2*tr+tp))+4);
end

S = exp(-gamma^2*Grad^2*tmp);

% Sin for OGSE
function S = sig_OGSE1(diameter, Din, smallDelta, bigDelta, freq, Grad, K)
gamma = 267.513e6; % 1e6*rad/(s*T)

tmp = 0;
for k = 1:K
    [Bk, lambda_k] = calcBk(diameter, k);
    tt = lambda_k*Din;
    tr=smallDelta/21;
    tp=smallDelta/21*3.5;
    tmp = tmp+ Bk/(tt^4*tr^2)*(4*exp(-tt*tp)-4*exp(-tt*tr)-4*exp(-2*tt*tr)-8*exp(-tt*bigDelta)-12*tt*tr+2*exp(-tt*(bigDelta-tr))...
        +2*exp(-tt*(bigDelta+tr))+2*exp(-tt*(bigDelta+2*tr))+2*exp(-tt*(bigDelta-2*tr))-2*exp(-tt*(bigDelta-tp))-2*exp(-tt*(bigDelta+tp))...
        -4*exp(-tt*(tr+tp))+2*exp(-tt*(tr+2*tp))-4*exp(-tt*(2*tr+tp))+4*exp(-tt*(3*tr+tp))-4*exp(-tt*(3*tr+2*tp))-4*exp(-tt*(3*tr+3*tp))...
        +4*exp(-tt*(4*tr+3*tp))+2*exp(-tt*(5*tr+2*tp))+4*exp(-tt*(5*tr+3*tp))+2*exp(-tt*(5*tr+4*tp))-4*exp(-tt*(6*tr+3*tp))-4*exp(-tt*(6*tr+4*tp))...
        +2*exp(-tt*(7*tr+4*tp))+6*tt^3*tr^3+8*tt^3*tr^2*tp+2*exp(-tt*(bigDelta-tr-tp))-exp(-tt*(bigDelta-tr-2*tp))+2*exp(-tt*(bigDelta+tr+tp))...
        +2*exp(-tt*(bigDelta-2*tr-tp))-exp(-tt*(bigDelta+tr+2*tp))+2*exp(-tt*(bigDelta+2*tr+tp))-2*exp(-tt*(bigDelta-3*tr-tp))-2*exp(-tt*(bigDelta+3*tr+tp))...
        +2*exp(-tt*(bigDelta+3*tr+2*tp))+2*exp(-tt*(bigDelta-3*tr-2*tp))+2*exp(-tt*(bigDelta+3*tr+3*tp))+2*exp(-tt*(bigDelta-3*tr-3*tp))...
        -2*exp(-tt*(bigDelta+4*tr+3*tp))-2*exp(-tt*(bigDelta-4*tr-3*tp))-exp(-tt*(bigDelta+5*tr+2*tp))-exp(-tt*(bigDelta-5*tr-2*tp))...
        -2*exp(-tt*(bigDelta+5*tr+3*tp))-2*exp(-tt*(bigDelta-5*tr-3*tp))-exp(-tt*(bigDelta+5*tr+4*tp))-exp(-tt*(bigDelta-5*tr-4*tp))...
        +2*exp(-tt*(bigDelta+6*tr+3*tp))+2*exp(-tt*(bigDelta-6*tr-3*tp))+2*exp(-tt*(bigDelta+6*tr+4*tp))+2*exp(-tt*(bigDelta-6*tr-4*tp))...
        -exp(-tt*(bigDelta+7*tr+4*tp))-exp(-tt*(bigDelta-7*tr-4*tp))+8);
end

S = exp(-gamma^2*Grad^2*tmp);

function S = sig_OGSE2(diameter, Din, smallDelta, bigDelta, freq, Grad, K)
gamma = 267.513e6; % 1e6*rad/(s*T)

tmp = 0;
for k = 1:K
    [Bk, lambda_k] = calcBk(diameter, k);
    tt = lambda_k*Din;
    tr=smallDelta/41;
    tp=smallDelta/41*3.5;
    tmp = tmp+  Bk/(tt^4*tr^2)*(4*exp(-tt*tp)-4*exp(-tt*tr)-8*exp(-2*tt*tr)-12*exp(-tt*bigDelta)-20*tt*tr+2*exp(-tt*(bigDelta-tr))...
        +2*exp(-tt*(bigDelta+tr))+4*exp(-tt*(bigDelta+2*tr))+4*exp(-tt*(bigDelta-2*tr))-2*exp(-tt*(bigDelta-tp))-2*exp(-tt*(bigDelta+tp))...
        -4*exp(-tt*(tr+tp))+6*exp(-tt*(tr+2*tp))-4*exp(-tt*(2*tr+tp))+4*exp(-tt*(3*tr+tp))-12*exp(-tt*(3*tr+2*tp))-4*exp(-tt*(3*tr+3*tp))...
        +4*exp(-tt*(4*tr+3*tp))+6*exp(-tt*(5*tr+2*tp))-4*exp(-tt*(4*tr+4*tp))+4*exp(-tt*(5*tr+3*tp))-4*exp(-tt*(6*tr+3*tp))+8*exp(-tt*(6*tr+4*tp))...
        +4*exp(-tt*(6*tr+5*tp))-4*exp(-tt*(7*tr+5*tp))-4*exp(-tt*(8*tr+4*tp))+2*exp(-tt*(7*tr+6*tp))-4*exp(-tt*(8*tr+5*tp))+4*exp(-tt*(9*tr+5*tp))...
        -4*exp(-tt*(9*tr+6*tp))-4*exp(-tt*(9*tr+7*tp))+4*exp(-tt*(10*tr+7*tp))+2*exp(-tt*(11*tr+6*tp))+4*exp(-tt*(11*tr+7*tp))+2*exp(-tt*(11*tr+8*tp))...
        -4*exp(-tt*(12*tr+7*tp))-4*exp(-tt*(12*tr+8*tp))+2*exp(-tt*(13*tr+8*tp))+38/3*tt^3*tr^3+16*tt^3*tr^2*tp+2*exp(-tt*(bigDelta-tr-tp))...
        -3*exp(-tt*(bigDelta-tr-2*tp))+2*exp(-tt*(bigDelta+tr+tp))+2*exp(-tt*(bigDelta-2*tr-tp))-3*exp(-tt*(bigDelta+tr+2*tp))...
        +2*exp(-tt*(bigDelta+2*tr+tp))-2*exp(-tt*(bigDelta-3*tr-tp))-2*exp(-tt*(bigDelta+3*tr+tp))+6*exp(-tt*(bigDelta+3*tr+2*tp))...
        +6*exp(-tt*(bigDelta-3*tr-2*tp))+2*exp(-tt*(bigDelta+3*tr+3*tp))+2*exp(-tt*(bigDelta-3*tr-3*tp))-2*exp(-tt*(bigDelta+4*tr+3*tp))...
        -2*exp(-tt*(bigDelta-4*tr-3*tp))-3*exp(-tt*(bigDelta+5*tr+2*tp))-3*exp(-tt*(bigDelta-5*tr-2*tp))+2*exp(-tt*(bigDelta+4*tr+4*tp))...
        +2*exp(-tt*(bigDelta-4*tr-4*tp))-2*exp(-tt*(bigDelta+5*tr+3*tp))-2*exp(-tt*(bigDelta-5*tr-3*tp))+2*exp(-tt*(bigDelta+6*tr+3*tp))...
        +2*exp(-tt*(bigDelta-6*tr-3*tp))-4*exp(-tt*(bigDelta+6*tr+4*tp))-4*exp(-tt*(bigDelta-6*tr-4*tp))-2*exp(-tt*(bigDelta+6*tr+5*tp))...
        -2*exp(-tt*(bigDelta-6*tr-5*tp))+2*exp(-tt*(bigDelta+7*tr+5*tp))+2*exp(-tt*(bigDelta-7*tr-5*tp))+2*exp(-tt*(bigDelta+8*tr+3*tp))...
        +2*exp(-tt*(bigDelta-8*tr-4*tp))-exp(-tt*(bigDelta+7*tr+6*tp))-exp(-tt*(bigDelta-7*tr-6*tp))+2*exp(-tt*(bigDelta+8*tr+5*tp))...
        +2*exp(-tt*(bigDelta-8*tr-5*tp))-2*exp(-tt*(bigDelta+9*tr+5*tp))-2*exp(-tt*(bigDelta-9*tr-5*tp))+2*exp(-tt*(bigDelta+9*tr+6*tp))...
        +2*exp(-tt*(bigDelta-9*tr-6*tp))+2*exp(-tt*(bigDelta+9*tr+7*tp))+2*exp(-tt*(bigDelta-9*tr-7*tp))-2*exp(-tt*(bigDelta+10*tr+7*tp))...
        -2*exp(-tt*(bigDelta-10*tr-7*tp))-exp(-tt*(bigDelta+11*tr+6*tp))-exp(-tt*(bigDelta-11*tr-6*tp))-2*exp(-tt*(bigDelta+11*tr+7*tp))...
        -2*exp(-tt*(bigDelta-11*tr-7*tp))-exp(-tt*(bigDelta+11*tr+8*tp))-exp(-tt*(bigDelta-11*tr-8*tp))+2*exp(-tt*(bigDelta+12*tr+7*tp))...
        +2*exp(-tt*(bigDelta-12*tr-7*tp))+2*exp(-tt*(bigDelta+12*tr+8*tp))+2*exp(-tt*(bigDelta-12*tr-8*tp))-exp(-tt*(bigDelta+13*tr+8*tp))...
        -exp(-tt*(bigDelta-13*tr-8*tp))+12);
end

S = exp(-gamma^2*Grad^2*tmp);

function [Bk, lambda_k] = calcBk(diameter, k)

%root_cyl = HL_FindRealRoots(@(x) x*(besselj(1/2,x)-besselj(5/2,x))-besselj(3/2,x),0.1,100,200);
root_cyl = [2.0816 5.9404 9.2058 12.4044 15.5792 18.7426 21.8997 25.0528 28.2034 31.3521 34.4995 37.6460 40.7917];
%root_cyl = FindRealRoots(@(x) (besselj(2,x)-besselj(0,x)),0.1,100,200);

%Bk = 2*(diameter/2/root_cyl(k)).^2./(root_cyl(k)^2 - 1); %cylinder
%lambda_k = (root_cyl(k)/(diameter/2)).^2; % cylinder
Bk = 2*(diameter/2/root_cyl(k)).^2./(root_cyl(k)^2 - 2); %cell
lambda_k = (root_cyl(k)/(diameter/2)).^2; % cell
%lambda_k = pi^2*(2*k-1)^2/diameter^2;
%a = 0e-6; % from um to m
%b = 20e-6; % from um to m
%Bk = 2*a^3*b^3*((besselj(0,lambda_k*a)-besselj(2,lambda_k*a))/2-(besselj(0,lambda_k*b)-besselj(2,lambda_k*b))/2)^2/...
%   (lambda_k^2*(b^3-a^3)*((a^3*(lambda_k^2*b^2-2)*(besselj(0,lambda_k*a)-besselj(2,lambda_k*a))/2)-...
%   b^3*(lambda_k^2*a^2-2)*(besselj(0,lambda_k*b)-besselj(2,lambda_k*b))/2));
