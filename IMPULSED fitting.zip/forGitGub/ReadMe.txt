Matlab code for IMPULSED fitting

Note: Parameters in this code are tailded to the examplery data of diffusion MRI data at OGSE-33Hz (b=0,300,600 mm2/s), OGSE-17Hz (b=0,400,800,1200 mm2/s), and PGSE-30ms (b=0,400,800,1200 mm2/s). 
